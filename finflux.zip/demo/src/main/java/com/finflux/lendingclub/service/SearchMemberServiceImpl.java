package com.finflux.lendingclub.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finflux.lendingclub.dao.ILoanRepository;
import com.finflux.lendingclub.valueobjects.Loan;
@Service
public class SearchMemberServiceImpl {
	@Autowired
	ILoanRepository loanRepository;
	
	public Loan searchMemberByID(int memberId)
	{
		Optional<Loan> loan = loanRepository.findById(memberId);
		return loan.get();
	}
}
