package com.finflux.lendingclub.valueobjects;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="loan")
public class Loan {
	@Id
	private int member_id;
	private int loan_amnt;
	private int funded_amnt_inv;
	private String term;
	private double int_rate;
	private double installment;
	private String grade;
	private String emp_title;
	private String emp_length;
	private String home_ownership;
	private int annual_inc;
	private String verification_status;
	private String issue_d;
	private String loan_status;
	private String desc;
	private String purpose;
	private String title;
	private String addr_state;
	private String last_pymnt_d;
	private double last_pymnt_amnt;

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public int getLoan_amnt() {
		return loan_amnt;
	}

	public void setLoan_amnt(int loan_amnt) {
		this.loan_amnt = loan_amnt;
	}

	public int getFunded_amnt_inv() {
		return funded_amnt_inv;
	}

	public void setFunded_amnt_inv(int funded_amnt_inv) {
		this.funded_amnt_inv = funded_amnt_inv;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public double getInt_rate() {
		return int_rate;
	}

	public void setInt_rate(double int_rate) {
		this.int_rate = int_rate;
	}

	public double getInstallment() {
		return installment;
	}

	public void setInstallment(double installment) {
		this.installment = installment;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getEmp_title() {
		return emp_title;
	}

	public void setEmp_title(String emp_title) {
		this.emp_title = emp_title;
	}

	public String getEmp_length() {
		return emp_length;
	}

	public void setEmp_length(String emp_length) {
		this.emp_length = emp_length;
	}

	public String getHome_ownership() {
		return home_ownership;
	}

	public void setHome_ownership(String home_ownership) {
		this.home_ownership = home_ownership;
	}

	public int getAnnual_inc() {
		return annual_inc;
	}

	public void setAnnual_inc(int annual_inc) {
		this.annual_inc = annual_inc;
	}

	public String getVerification_status() {
		return verification_status;
	}

	public void setVerification_status(String verification_status) {
		this.verification_status = verification_status;
	}

	public String getIssue_d() {
		return issue_d;
	}

	public void setIssue_d(String issue_d) {
		this.issue_d = issue_d;
	}

	public String getLoan_status() {
		return loan_status;
	}

	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddr_state() {
		return addr_state;
	}

	public void setAddr_state(String addr_state) {
		this.addr_state = addr_state;
	}

	public String getLast_pymnt_d() {
		return last_pymnt_d;
	}

	public void setLast_pymnt_d(String last_pymnt_d) {
		this.last_pymnt_d = last_pymnt_d;
	}

	public double getLast_pymnt_amnt() {
		return last_pymnt_amnt;
	}

	public void setLast_pymnt_amnt(double last_pymnt_amnt) {
		this.last_pymnt_amnt = last_pymnt_amnt;
	}
}
