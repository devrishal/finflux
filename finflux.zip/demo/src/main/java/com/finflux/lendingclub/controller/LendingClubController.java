package com.finflux.lendingclub.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finflux.lendingclub.service.SearchMemberServiceImpl;
import com.finflux.lendingclub.valueobjects.Loan;

@RestController
@RequestMapping("/lendingclub/v1")
public class LendingClubController {
	@Autowired
	SearchMemberServiceImpl searchMemberServiceimpl;
	
	@GetMapping("/search/{memberid}")
	public Loan searchCustomersByMemberID(@PathVariable("memberid") String memberId)
	{
		Loan loan = searchMemberServiceimpl.searchMemberByID(Integer.valueOf(memberId));
		return loan;
	}
}
